//
//  ViewController.swift
//  Lab3
//
//  Created by Syed Shahbaz on 2024-03-10.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, UITextFieldDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var weatherConditionImage: UIImageView!
    
    
    @IBOutlet weak var temperatureLabel: UILabel!

    @IBOutlet weak var temperatureUnitToggle: UISwitch!
    
    
    @IBOutlet weak var weatherConditionLabel: UILabel!
    
    
    
    @IBOutlet weak var locationLabel: UILabel!
    let locationManager = CLLocationManager()
    
    var isFahrenheit: Bool = false
    var weatherResponse: WeatherResponse?

    let conditionMappings: [Int: (day: String, night: String, symbolName: String)] = [
        1000: ("Sunny", "Clear", "sun.max.fill"),
        1003: ("Partly cloudy", "Partly cloudy", "cloud.sun.fill"),
        1006: ("Cloudy", "Cloudy", "cloud.fill"),
        1009: ("Overcast", "Overcast", "smoke.fill"),
        1117: ("Blizzard", "Blizzard", "cloud.snow.fill"),
        1135: ("Overcast", "Overcast", "cloud.fill"),
        1030: ("Mist", "Mist", "cloud.fog.fill")
    ]


    
    override func viewDidLoad() {
        super.viewDidLoad()
        displaySampleImageForDemo()
        searchTextField.delegate = self
        locationManager.delegate = self
        updateTemperatureUnit()
        temperatureUnitToggle.isEnabled = true
    }
    
    
    
    @IBAction func temperatureUnitToggleChanged(_ sender: UISwitch) {
        print("Toggle Changed")
            print("isFahrenheit: \(sender.isOn)")
           isFahrenheit = sender.isOn
           updateTemperatureUnit()
        }
        
    private func updateTemperatureUnit() {
        if let weatherResponse = weatherResponse {
            print("Weather response is not nil")
            if isFahrenheit {
                temperatureLabel.text = "\(convertToCelsiusOrFahrenheit(weatherResponse.current.temp_f))°F"
            } else {
                temperatureLabel.text = "\(convertToCelsiusOrFahrenheit(weatherResponse.current.temp_c))°C"
            }
        } else {
            print("Weather response is nil")
        }
    }




    
    private func convertToCelsiusOrFahrenheit(_ temperature: Float) -> Float {
            return isFahrenheit ? (temperature * 9/5) + 32 : temperature
        }


    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.endEditing(true)
            if let searchText = textField.text {
                loadWeather(search: searchText)
            }
            return true
        }

    
    private func displaySampleImageForDemo(){
        let config = UIImage.SymbolConfiguration(paletteColors: [
            .systemRed, .systemTeal, .systemYellow
        ])
        weatherConditionImage.preferredSymbolConfiguration = config
        
        
        weatherConditionImage.image =  UIImage(systemName: "person.3.sequence")
    }
    
    @IBAction func onLocationTapped(_ sender: UIButton) {
        requestLocation()
    }
    @IBAction func onSearchTapped(_ sender: UIButton) {
        if searchTextField.text != nil {
            loadWeather(search: searchTextField.text)
        }
    }
    
  



    
    
    private func loadWeather(search: String?) {
        guard let search = search else {
            return
        }
        
        guard let url = getURL(query: search) else {
            print("Could not get URL")
            return
        }
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: url) { [weak self] data, response, error in
            guard let self = self else { return }
            
            print("Network call complete")
            
            if let error = error {
                print("Error fetching data:", error.localizedDescription)
                return
            }
            
            guard let data = data else {
                print("No data found")
                return
            }
            
            if let weatherResponse = self.parseJson(data: data) {
                print("Weather response:", weatherResponse)
                
                DispatchQueue.main.async {
                    self.locationLabel.text = weatherResponse.location.name
                    self.temperatureLabel.text = "\(weatherResponse.current.temp_c)°C"
                    
                    // Update UI with weather condition data
                    self.updateUI(with: weatherResponse)
                    
                    self.temperatureUnitToggle.isEnabled = true
                }
            } else {
                print("Failed to parse weather data")
            }
        }
        dataTask.resume()
    }

   
    private func updateUI(with weatherResponse: WeatherResponse) {
        print("Updating UI with weather data")
        
      
        let weatherConditionText = weatherResponse.current.condition.text
        print("Weather Condition Text:", weatherConditionText)
        weatherConditionLabel.text = "Weather Condition: \(weatherConditionText)"
        
       
        guard let conditionMapping = conditionMappings[weatherResponse.current.condition.code] else {
            print("Unknown condition code")
            return
        }
        
       
        let symbolImage = UIImage(systemName: conditionMapping.symbolName)
        
        weatherConditionImage.image = symbolImage
    }




    private func customizeUI() {
        view.backgroundColor = .systemBackground
        searchTextField.textColor = .label
    }
    
    private func requestLocation() {
           locationManager.requestWhenInUseAuthorization()
           locationManager.requestLocation()
       }
       
       func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
           guard let location = locations.last else { return }
           let latitude = location.coordinate.latitude
           let longitude = location.coordinate.longitude
           fetchWeatherForLocation(latitude: latitude, longitude: longitude)
       }
       
       func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
           print("Failed to obtain location:", error.localizedDescription)
       }
    
    private func fetchWeatherForLocation(latitude: Double, longitude: Double) {
           let urlString = "https://api.weatherapi.com/v1/current.json?key=e4083862a5134c87893170555241603&q=\(latitude),\(longitude)"
           guard let url = URL(string: urlString) else {
               print("Invalid URL")
               return
           }
           fetchData(from: url)
       }
    
    private func getURL(query: String) ->  URL? {
        let baseUrl = "https://api.weatherapi.com/v1/"
        let currentEndpoint = "current.json"
        let apiKey = "e4083862a5134c87893170555241603"
        let url = "\(baseUrl)\(currentEndpoint)?key=\(apiKey)&q=\(query)"
        
        return URL(string: url)
    }
    
    
private func fetchData(from url: URL) {
    URLSession.shared.dataTask(with: url) { [self] data, response, error in
        guard let data = data, error == nil else {
            print("Error fetching data:", error?.localizedDescription ?? "Unknown error")
            return
        }
        
        if let weatherResponse = parseJson(data: data) {
            print("Parsed weather data:", weatherResponse)

            self.weatherResponse = weatherResponse
            DispatchQueue.main.async {
                self.locationLabel.text = weatherResponse.location.name
                self.temperatureLabel.text = "\(weatherResponse.current.temp_c)°C"
                
                if let mapping = self.conditionMappings[weatherResponse.current.condition.code] {
                    let isDaytime = self.isDaytime()
                    let weatherStatus = isDaytime ? mapping.day : mapping.night
                    print("Weather status: \(weatherStatus)")
                    
                    self.weatherConditionImage.image = UIImage(systemName: mapping.symbolName)
                }
            }
        }
    }.resume()
}



    
    
    private func parseJson(data: Data) -> WeatherResponse? {
        let decoder = JSONDecoder()
        do {
            let weather = try decoder.decode(WeatherResponse.self, from: data)
            print("Successfully decoded weather data:", weather)
            return weather
        } catch {
            print("Error decoding JSON:", error)
            return nil
        }
    }


       
       private func isDaytime() -> Bool {
           let hour = Calendar.current.component(.hour, from: Date())
           return hour >= 6 && hour < 18
       }
   }

//    private func parseJson(data: Data) -> WeatherResponse?{
//        let decoder = JSONDecoder()
//        var weather: WeatherResponse?
//        do{
//            weather = try decoder.decode(WeatherResponse.self, from: data)
//        } catch { 
//            print("Error decoding")
//        }
//        return weather
//    }
    
    
    

    struct WeatherResponse: Decodable{
        let location: Location
        let current: Weather
    }
    
    struct Location: Decodable{
        let name: String
    }
    
    struct Weather:  Decodable{
        let temp_c: Float
        let temp_f: Float
        let condition: WeatherCondition
    }
    
    struct WeatherCondition : Decodable{
        let text: String
        let code: Int
    }
